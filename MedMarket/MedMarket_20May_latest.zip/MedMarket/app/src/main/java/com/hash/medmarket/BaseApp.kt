package com.hash.medmarket

import android.app.Application

class BaseApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}