package com.hash.medmarket.notifications

object AllConstants {

    @JvmField
    var CHANNEL_ID  = "1000"
}