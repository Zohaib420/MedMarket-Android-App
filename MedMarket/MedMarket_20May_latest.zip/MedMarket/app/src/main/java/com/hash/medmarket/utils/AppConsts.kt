package com.hash.medmarket.utils


object AppConsts {

    var userType = "pharmacist"

    const val JPG_EXT = ".jpg"

    const val APPLICATION_ID = "com.hash.medmarket"

}
