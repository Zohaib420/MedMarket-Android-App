package com.hash.medmarket.model.notification

data class NotificationModel(
    var id: Int? = null,
    var title: String? = null,
    var message: String? = null,
    var date: String? = null,
    var status: String? = null
)
