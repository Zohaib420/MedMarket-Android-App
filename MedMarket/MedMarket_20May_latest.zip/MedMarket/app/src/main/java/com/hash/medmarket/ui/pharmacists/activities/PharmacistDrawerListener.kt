package com.hash.medmarket.ui.pharmacists.activities

interface PharmacistDrawerListener {
    fun openDrawer()
    fun closeDrawer()
}